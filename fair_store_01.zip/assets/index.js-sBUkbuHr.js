(function(){class c{document;options;constructor(e,t){this.document=e,this.options=t}render(){const e=this.document.getElementById(this.options.id);if(e instanceof HTMLDivElement)return e;const{body:t}=this.document;if(!t)return null;const o=this.document.createElement("div");return o.id=this.options.id,o.textContent=this.options.text,this.applyStyles(o),t.appendChild(o),o}applyStyles(e){Object.entries(this.options.styles).forEach(([t,o])=>{e.style.setProperty(t,o)})}}class v{document;options;overlayElement=null;constructor(e,t){this.document=e,this.options=t}render(){const e=this.document.getElementById(this.options.id);if(e instanceof HTMLDivElement)return e;const{body:t}=this.document;return t?(this.overlayElement=this.document.createElement("div"),this.overlayElement.id=this.options.id,this.applyStyles(this.overlayElement),this.overlayElement.innerHTML=this.createWarningHTML(),this.attachEventListeners(this.overlayElement),t.appendChild(this.overlayElement),this.overlayElement):null}createWarningHTML(){const e=this.options.domain||window.location.hostname,t=this.options.reason||"Tento e-shop je veden v seznamu rizikových provozoven České obchodní inspekce.";return`
      <div class="fair-store-warning-container">
        <div class="fair-store-warning-header">
          <svg class="fair-store-warning-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9V11M12 15H12.01M5.07183 19H18.9282C20.4678 19 21.4301 17.3333 20.6603 16L13.7321 4C12.9623 2.66667 11.0378 2.66667 10.268 4L3.33978 16C2.56998 17.3333 3.53223 19 5.07183 19Z" 
                  stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <h1 class="fair-store-warning-title">Varování: Rizikový e-shop!</h1>
        </div>

        <div class="fair-store-warning-content">
          <p class="fair-store-warning-text">
            Navštívili jste potenciálně podvodný e-shop: <strong>${this.escapeHtml(e)}</strong>
          </p>
          
          <div class="fair-store-warning-source">
            <div class="fair-store-source-badge">
              <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" 
                      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              Ověřeno podle dat ČOI
            </div>
          </div>

          <div class="fair-store-details-section">
            <button class="fair-store-details-toggle" id="fair-store-toggle-details" aria-expanded="false">
              <svg class="fair-store-chevron" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M19 9L12 16L5 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              Zobrazit důvod varování
            </button>
            <div class="fair-store-details-content" id="fair-store-details-content">
              <div class="fair-store-coi-reason">
                <h3>Důvod zařazení do seznamu ČOI:</h3>
                <p>${this.escapeHtml(t)}</p>
              </div>
            </div>
          </div>

          <div class="fair-store-warning-advice">
            <strong>🛡️ Doporučení:</strong> Tuto stránku raději opusťte a nakupujte pouze u ověřených prodejců. 
            Rizikové e-shopy mohou ukrást vaše osobní údaje nebo peníze.
          </div>
        </div>

        <div class="fair-store-warning-actions">
          <button class="fair-store-btn fair-store-btn-primary" id="fair-store-close-tab">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M6 18L18 6M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            Zavřít kartu
          </button>
          <button class="fair-store-btn fair-store-btn-secondary" id="fair-store-ignore-warning">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M13 7H11V13H13V7ZM13 15H11V17H13V15Z" fill="currentColor"/>
              <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2Z" 
                    stroke="currentColor" stroke-width="2"/>
            </svg>
            Pokračovat na vlastní riziko
          </button>
        </div>

        <div class="fair-store-warning-footer">
          <p>
            Ochrana poskytována rozšířením <strong>Fair Store</strong> · 
            Data: Česká obchodní inspekce
          </p>
        </div>
      </div>
    `}escapeHtml(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}attachEventListeners(e){const t=e.querySelector("#fair-store-close-tab");t&&t.addEventListener("click",()=>{window.close(),setTimeout(()=>{window.history.length>1?window.history.back():window.location.href="about:blank"},100)});const o=e.querySelector("#fair-store-ignore-warning");o&&o.addEventListener("click",()=>{this.remove()});const i=e.querySelector("#fair-store-toggle-details"),a=e.querySelector("#fair-store-details-content"),s=e.querySelector(".fair-store-chevron");i&&a&&i.addEventListener("click",()=>{const l=i.getAttribute("aria-expanded")==="true";i.setAttribute("aria-expanded",(!l).toString()),l?(a.classList.remove("expanded"),s&&(s.style.transform="rotate(0deg)")):(a.classList.add("expanded"),s&&(s.style.transform="rotate(180deg)"))})}applyStyles(e){Object.entries(this.options.styles).forEach(([t,o])=>{e.style.setProperty(t,o)})}remove(){this.overlayElement&&this.overlayElement.parentNode&&(this.overlayElement.parentNode.removeChild(this.overlayElement),this.overlayElement=null)}}let r=null;function h(){const n=document.readyState;return n==="complete"||n==="interactive"}function d(n,e){const t=()=>{r||(r=new c(document,{id:"fair-store-scam-banner",text:"Rizikový e-shop!",styles:{position:"fixed",top:"0",left:"0",right:"0",width:"100%",padding:"12px 16px","background-color":"#d32f2f",color:"#ffffff","font-family":"sans-serif","font-size":"20px","font-weight":"bold","text-align":"center","z-index":"2147483647","box-shadow":"0 2px 6px rgba(0, 0, 0, 0.3)","pointer-events":"none"}})),r.render(),new v(document,{id:"fair-store-warning-overlay",styles:{},domain:n,reason:e||void 0}).render()};h()?t():document.addEventListener("DOMContentLoaded",t,{once:!0})}chrome.runtime.onMessage.addListener((n,e,t)=>{if(n.action==="showWarning")return d(n.domain||n.matchedDomain,n.reason),t({success:!0}),!0;if(n.action==="hideWarning"){r&&r.remove();const o=document.getElementById("fair-store-warning-overlay");return o&&o.remove(),t({success:!0}),!0}return!1});chrome.runtime.sendMessage({action:"checkDomain",url:window.location.href},n=>{if(chrome.runtime.lastError){console.error("Fair Store:",chrome.runtime.lastError);return}n?.isScam&&n?.protectionEnabled&&d(n.domain||n.matchedDomain,n.reason)});
})()